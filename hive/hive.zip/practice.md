## Task 1
#### Docker is running
![docker_running.png](task1%2Fdocker_running.png)

### Expand customers table

![expand_customers.png](task1%2Fexpand_customers.png)

Write a query to fetch the following:
-	Just the employee ID, first name and last name 
-	Employee number should be between 1002 and 1100
-	Order by last name in descending order
-	Fetch only first five rows

~~~~
select employeenumber, firstname, lastname
from employees
where employeenumber between 1002 and 1100
order by lastname desc
limit 10
~~~~

![query_1.png](task1%2Fquery_1.png)

#### How many employees per job title, ordered by number of employees in descending order?

~~~~
select jobtitle, count(employeenumber) number_of_employee
from employees
group by jobtitle
order by number_of_employee desc
~~~~
![query_2.png](task1%2Fquery_2.png)

Exported result of the query : 

[export_query.csv](task1%2Fexport_query.csv)

Location of the employees table

![location_employee.png](task1%2Flocation_employee.png)

--- 

## Task 2
Establishing connection to hive with beeline : 

![connect_using_beeline.png](task2%2Fconnect_using_beeline.png)

Available databases : 

![show_database.png](task2%2Fshow_database.png)

Show all tables :

![show_tables.png](task2%2Fshow_tables.png)

Creating newdb and verifying it :  

![create_verify_newdb.png](task2%2Fcreate_verify_newdb.png)

Create a table “new_emp” in “newdb” which is identical to the “Employees” table in “ClassicModels” database (Both schema and data):

![create_new_emp.png](task2%2Fcreate_new_emp.png)

Populate

![populate.png](task2%2Fpopulate.png)

--- 

## Task 3 
Table properties

![table_properties.png](task3%2Ftable_properties.png)

- Location : hdfs://localhost:9000/user/hive/warehouse/newdb.db/new_emp
- Table type : MANAGED_TABLE
- Num files : 1

Examining hdfs directory for this table 

![examine_hdfs_emp.png](task3%2Fexamine_hdfs_emp.png)

- Num files : 1 
- Content is readable

After dropping the new_emp table
 
![after_drop_1.png](task3%2Fafter_drop_1.png)

The file is not exist. Because the table was created as a managed table, the data files will be deleted when the table is dropped.

External table creation

![error_external.png](task3%2Ferror_external.png)

Check

![check_2.png](task3%2Fcheck_2.png)

- location : hdfs://localhost:9000/user/hive/warehouse/newdb.db/new_emp
- table_type: EXTERNAL
- file type : Text

After dropping the table

![drop_2.png](task3%2Fdrop_2.png)

File is exist because it is when the table is EXTERNAL, it is not deleted

Manual delete :

![manual_delete.png](task3%2Fmanual_delete.png)

--- 

### Task 4
How many customers we have in each country?

~~~~
select country, count(customernumber) amount 
from customers
group by country
order by amount desc;
~~~~

![employe_by_country.png](task4%2Femploye_by_country.png)

Full DDL of customers table

![ddl_customers.png](task4%2Fddl_customers.png)

Modify the CREATE TABLE command, to create a new table with the following characteristics:
- DB Name: “ClassicModels”
- Table name: “cust_country”
- Partitioned By: “country” column
- File type: AVRO

~~~~
CREATE TABLE `cust_country`(
	  `customernumber` int, 
	  `customername` string, 
	  `contactlastname` string, 
	  `contactfirstname` string, 
	  `phone` string, 
	  `addressline1` string, 
	  `addressline2` string, 
	  `city` string, 
	  `state` string, 
	  `postalcode` string, 
	  `salesrepemployeenumber` int, 
	  `creditlimit` double)
PARTITIONED BY (country string)
STORED AS AVRO;
~~~~

Insert data into the “Cust_Country” from the “Customers” table (Limit to 50 rows), 
so that partitions will be generated and populated dynamically.

~~~~
INSERT INTO TABLE cust_country PARTITION (country)
SELECT customernumber, customername, contactlastname, contactfirstname, phone, addressline1, addressline2, city, state, postalcode, salesrepemployeenumber, creditlimit, country
FROM customers
limit 50;
~~~~
cust_country table customers from USA 

![customers_usa_1.png](task4%2Fcustomers_usa_1.png)
![customers_usa_2.png](task4%2Fcustomers_usa_2.png)

Examine the execution plan of the query to verify partition elimination has occurred
~~~
EXPLAIN SELECT * FROM cust_country WHERE country='USA';
EXPLAIN DEPENDENCY SELECT * FROM cust_country WHERE country='USA';
~~~
![examine_execution_plan.png](task4%2Fexamine_execution_plan.png)

Why is partitioning so important for query performance?
- Because with partitioning we can just focus on the partitioned table where filters meet and this saves great resourse and time in the big datasets

Contents and subdirectories of this table : 

` hdfs dfs -ls /user/hive/warehouse/classicmodels.db/cust_country/`

![cust_country_directories.png](task4%2Fcust_country_directories.png)

---

## Task 5
Create a new transactional table called “my_emp” with the following properties:

Columns:
- ID – INT
- Name – STRING
- Salary – INT
- File type: ORC
- Transactional…

~~~~
CREATE TABLE my_emp (ID INT, Name STRING, Salary INT)
STORED AS ORC TBLPROPERTIES ('transactional'='true');
~~~~

Does this table supports DML operations?

~~~
DESCRIBE FORMATTED my_emp;
~~~

![dml_support.png](task5%2Fdml_support.png)

Insert 3 rows to this table in a single INSERT command:
- 1, John, 10000
- 2, Sara, 12000
- 3, Adam, 8000

~~~
INSERT INTO my_emp VALUES (1, 'John', 10000), (2, 'Sara', 12000), (3, 'Adam', 8000);
~~~

![after_1st_insert.png](task5%2Fafter_1st_insert.png)

Update Adam’s salary in “my_emp” to 9000

~~~
UPDATE my_emp SET Salary = 9000 WHERE Name = 'Adam';
~~~

Insert a new row to “my_emp”
- 4, Alex, 13000
~~~
INSERT INTO my_emp VALUES (4, 'Alex', 13000);
~~~
Delete John from the table.
~~~
DELETE FROM my_emp WHERE Name = 'John';
~~~
Query “my_emp” to verify you see all changes performed.

![last_verify.png](task5%2Flast_verify.png)